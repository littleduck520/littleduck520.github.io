module.exports = {
  singleQuote: true,
  plugins: ['prettier-plugin-tailwindcss'],
};
